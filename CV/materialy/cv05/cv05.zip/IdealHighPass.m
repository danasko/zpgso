function im = IdealHighPass(I,D)
% D is the circular cutoff frequency which is normalized to  % [0 1]
if length(size(I))>2
    I = rgb2gray(I);
end
I = im2double(I);
% create 2 matrices containing for each pixel its distance from image center 
[row, col] = size(I);
hr = (row-1)/2;
hc = (col-1)/2;
[x, y] = meshgrid(-hc:hc, -hr:hr);
% calculate normalized distance from origin(a.k.a magnitude)
mg = sqrt((x/hc).^2 + (y/hr).^2);

% create a logic mask based on threshold D
L = mg >= D;
% img to freq. domain
IM = fftshift(fft2(I)); 
% filter -> pass only pixels with distance from origin > D
IP = IM .* L;  
% img back to image domain
im = abs(ifft2(ifftshift(IP))); 
end